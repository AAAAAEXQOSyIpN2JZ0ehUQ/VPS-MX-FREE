# Script Manager (VPS-MX-8.1 -8.2 -8.3)
Info de Instalador y ficheros del Scrip VPS-MX

# TEAM : ILLUMINATI

# 
# Repositorios Oficiales
# CAMBIOS
# CAMBIO DE VERSION Y BARRAS {'-'} 8.1 -8.2

# DESARROLLADO POR 
@kalix1
# Créditos : @kalix1
# 
# Grupo y canal
# @conectedmx
# @conectedmx_vip
