# Script by reaper ¡gamo
![](https://github.com/casitadelterror/scripts/raw/master/gamo/panel.png)

# 
#
#### 
grupo: @conectedmx_vip
#### 
canal: @conectedmx
### 
creditos: casitadelterror
### 
creditos : internos de cada script
### 
# creditos: kalix1
 # 
![](https://img.shields.io/badge/Ubuntu-14.04-orange)
![](https://img.shields.io/badge/Ubuntu-14.10-orange)
![](https://img.shields.io/badge/Ubuntu-16.04-orange)
![](https://img.shields.io/badge/Ubuntu-16.10-orange)
![](https://img.shields.io/badge/Ubuntu-18.04-orange)
![](https://img.shields.io/badge/Ubuntu-18.10-orange)
![](https://img.shields.io/badge/Ubuntu-19.04-orange)
![](https://img.shields.io/badge/Ubuntu-19.10-orange)
![](https://img.shields.io/badge/Debian-7-red)
![](https://img.shields.io/badge/Debian-8-red)
![](https://img.shields.io/badge/Debian-9-red)
![](https://img.shields.io/badge/Debian-10-red)

# paquetes
apt-get update; apt-get upgrade -y;
#### Instalacion
wget https://raw.githubusercontent.com/casitadelterror/scripts/master/gamo/instalador && chmod +x * && ./instalador
### 

