# Generdor Gen VPS-MX

Generador de keys para instalar el generador usando el link oficial

sudo apt-get update -y; apt-get upgrade -y; wget https://raw.githubusercontent.com/rudi9999/Generador_Gen_VPS-MX/master/instgerador.sh; chmod 777 instgerador.sh; ./instgerador.sh

=======================================================================

INSTALADOR DEL GENERADOR

sudo apt-get update -y; apt-get upgrade -y; wget https://www.dropbox.com/s/w0s2rv92wy7z3fq/instgerador.sh; sudo chmod 777 instgerador.sh; ./instgerador.sh

===============

COMPLETAMENTE FREE! 

===============


