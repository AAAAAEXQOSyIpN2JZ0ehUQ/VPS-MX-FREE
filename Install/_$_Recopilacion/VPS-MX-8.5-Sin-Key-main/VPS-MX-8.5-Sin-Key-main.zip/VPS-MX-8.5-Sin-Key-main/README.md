🔥🔥 VPS-MX 8.5x Sin Key 🔥 🔥 

Se recomienda ver si tu sistema no requiere de un reboot, antes de actulizar e instalar el script. 

INSTALADOR:

rm -rf Install-Sin-Key.sh; apt update; apt upgrade -y; wget https://raw.githubusercontent.com/VPS-MX/VPS-MX-8.5-Sin-Key/main/Install%20Sin%20KEY/Install-Sin-Key.sh; chmod 777 Install-Sin-Key.sh; ./Install-Sin-Key.sh

Nota: Todos los files se estaran subiendo de forma libre tanto para armar su propio generar como su instalador para cualquier vercion.
      Checar los Files sin SHC son los archivos oficiales open source

❗️🔥 PROYECTO FREE 8.5x 🔥❗️

▫️No se da soporte por MP ni  Grupo ni  Admin ni Reseller ayudara, todo sera presentando tu comint en git y se vera su peticion 

▫️No ayudo ni asesoro, si llegas a MP Banamex 

▫️Todos los archivos estan open y legibles verciones 8.2-8.3.8.4-8.5 para que los agrege asu generador o install sin key mediante un .tar

▫️Recomiendo  hacer un fork y editar enlaces en su propios fork y enlases raw y generar su propio tar
