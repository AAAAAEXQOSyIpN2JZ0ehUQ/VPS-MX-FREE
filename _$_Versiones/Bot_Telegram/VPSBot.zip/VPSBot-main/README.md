# VPSBot

sudo wget -O $HOME/update.sh https://raw.githubusercontent.com/rudi9999/VPSBot/main/update.sh; chmod +x $HOME/update.sh; $HOME/update.sh
